module.exports = { semi: true, singleQuote: false, tabWidth: 2 };
