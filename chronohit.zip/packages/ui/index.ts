export const brand = 'ChronoHit';
