export const redis = {
  async zrange(key: string, start: number, stop: number, opts?: any) {
    // placeholder: wire to Upstash REST
    return [];
  }
}