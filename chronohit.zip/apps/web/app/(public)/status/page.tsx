export default function Page() { return <h1 className='text-2xl font-bold'>System Status</h1>; }
