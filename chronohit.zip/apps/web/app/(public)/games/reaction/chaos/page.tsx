export default function Page() { return <h1 className='text-2xl font-bold'>Reaction • Chaos 4×4</h1>; }
