export default function Page() { return <h1 className='text-2xl font-bold'>Play Hub</h1>; }
